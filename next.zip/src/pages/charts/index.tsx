import React from 'react';
import HeroUnit from '../component/HeroUnit';

const index = () => {
    return (
        <div>
            <HeroUnit/>
        </div>
    );
};

export default index;