import React from 'react';

const piechart = () => {
    return (
        <div>
            Pie chart
        </div>
    );
};

export default piechart;